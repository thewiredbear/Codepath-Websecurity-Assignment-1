<?php

  // is_blank('abcd')
  function is_blank($value='') {
    // TODO
  }

  // has_length('abcd', ['min' => 3, 'max' => 5])
  function has_length($value, $options=array()) {
    // TODO
  }

  // has_valid_email_format('test@test.com')
  function has_valid_email_format($value) {
    // TODO
  }

?>
