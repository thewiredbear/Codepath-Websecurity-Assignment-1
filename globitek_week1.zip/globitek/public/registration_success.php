<?php
  require_once('../private/initialize.php');
?>

<?php $page_title = 'Registration Success'; ?>
<?php include(SHARED_PATH . '/header.php'); ?>

<div id="main-content">
  <h1>Registration Success</h1>
  <p>Your registration was submitted successfully.</p>
</div>

<?php include(SHARED_PATH . '/header.php'); ?>
